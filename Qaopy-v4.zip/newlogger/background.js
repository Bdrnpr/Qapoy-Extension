/* ============================================================
   qaopy – background.js (Service Worker)
   Privileged background fetch runner (Zero CORS restrictions)
   ============================================================ */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "REPLAY_REQUEST") {
    (async () => {
      const startTime = performance.now();
      try {
        const fetchHeaders = new Headers();
        if (msg.headers) {
          Object.entries(msg.headers).forEach(([k, v]) => {
            try {
              fetchHeaders.append(k, v);
            } catch (e) {
              console.warn("Could not append header:", k, e);
            }
          });
        }

        const options = {
          method: msg.method || "GET",
          headers: fetchHeaders,
        };

        if (!["GET", "HEAD"].includes(options.method) && msg.body) {
          options.body = msg.body;
        }

        const res = await fetch(msg.url, options);
        const duration = Math.round(performance.now() - startTime);
        const text = await res.text();

        sendResponse({
          ok: true,
          status: res.status,
          statusText: res.statusText || "",
          duration: duration,
          body: text,
        });
      } catch (err) {
        const duration = Math.round(performance.now() - startTime);
        sendResponse({
          ok: false,
          error: err.message || String(err),
          duration: duration,
        });
      }
    })();
    return true; // Keep message channel open for async sendResponse
  }

  if (msg.type === "TAKE_SCREENSHOT") {
    (async () => {
      try {
        let winId = null;
        if (msg.tabId) {
          try {
            const tab = await chrome.tabs.get(msg.tabId);
            if (tab) winId = tab.windowId;
          } catch (e) {}
        }

        try {
          const dataUrl = await chrome.tabs.captureVisibleTab(winId, { format: "png" });
          sendResponse({ ok: true, dataUrl });
        } catch (captureErr) {
          const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: "png" });
          sendResponse({ ok: true, dataUrl });
        }
      } catch (err) {
        sendResponse({ ok: false, error: err.message || String(err) });
      }
    })();
    return true;
  }

  // ── SET_MOCK ─────────────────────────────────────────────────
  // Intercepts a URL and returns a data: URI with the mock body.
  // NOTE: declarativeNetRequest redirect cannot control status code;
  // the browser always delivers a 200. This is a Chrome MV3 platform limit.
  if (msg.type === "SET_MOCK") {
    (async () => {
      try {
        const { url, body } = msg;
        if (!url) { sendResponse({ ok: false, error: "URL required" }); return; }

        // Load existing mocks from storage
        const stored = await chrome.storage.local.get("qaopy_mocks");
        const mocks  = stored.qaopy_mocks || {};

        // Assign a stable rule ID (1–1000 range for dynamic rules)
        // Use a hash of the URL to keep it consistent across reloads
        let ruleId = mocks[url]?.ruleId;
        if (!ruleId) {
          // Find next free ID
          const usedIds = Object.values(mocks).map(m => m.ruleId);
          ruleId = 1;
          while (usedIds.includes(ruleId)) ruleId++;
        }

        // Encode the response body as a data: URI
        const safeBody  = body || "{}";
        const dataUri   = "data:application/json;charset=utf-8," + encodeURIComponent(safeBody);

        // Build declarativeNetRequest rule
        const rule = {
          id: ruleId,
          priority: 100,
          action: {
            type: "redirect",
            redirect: { url: dataUri },
          },
          condition: {
            urlFilter: url,
            resourceTypes: ["xmlhttprequest"],
          },
        };

        // Remove old rule for this URL (if any) and add new one
        const oldId = mocks[url]?.ruleId;
        await chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: oldId ? [oldId] : [],
          addRules: [rule],
        });

        // Persist mock to storage
        mocks[url] = { ruleId, body: safeBody, status: msg.status || 200 };
        await chrome.storage.local.set({ qaopy_mocks: mocks });

        sendResponse({ ok: true, ruleId });
      } catch (err) {
        sendResponse({ ok: false, error: err.message || String(err) });
      }
    })();
    return true;
  }

  // ── CLEAR_MOCK ───────────────────────────────────────────────
  if (msg.type === "CLEAR_MOCK") {
    (async () => {
      try {
        const { url } = msg;
        const stored  = await chrome.storage.local.get("qaopy_mocks");
        const mocks   = stored.qaopy_mocks || {};
        const entry   = mocks[url];

        if (entry?.ruleId) {
          await chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [entry.ruleId],
            addRules: [],
          });
        }

        delete mocks[url];
        await chrome.storage.local.set({ qaopy_mocks: mocks });
        sendResponse({ ok: true });
      } catch (err) {
        sendResponse({ ok: false, error: err.message || String(err) });
      }
    })();
    return true;
  }

  // ── GET_MOCKS ────────────────────────────────────────────────
  if (msg.type === "GET_MOCKS") {
    chrome.storage.local.get("qaopy_mocks", result => {
      sendResponse({ ok: true, mocks: result.qaopy_mocks || {} });
    });
    return true;
  }
});

// ── REPLAY TARGETED CORS BYPASS RULE ──────────────────────────
// Applies ONLY to requests initiated by this extension (initiatorDomains: [chrome.runtime.id])
// Never interferes with or modifies normal web pages or browser traffic.
const REPLAY_CORS_RULE_ID = 9999;

async function setupReplayCORSRule() {
  if (!chrome.declarativeNetRequest || !chrome.runtime?.id) return;
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [REPLAY_CORS_RULE_ID],
      addRules: [
        {
          id: REPLAY_CORS_RULE_ID,
          priority: 999,
          action: {
            type: "modifyHeaders",
            requestHeaders: [
              { header: "origin", operation: "remove" },
              { header: "sec-fetch-mode", operation: "remove" },
              { header: "sec-fetch-site", operation: "remove" },
              { header: "sec-fetch-dest", operation: "remove" },
            ],
            responseHeaders: [
              { header: "access-control-allow-origin", operation: "set", value: "*" },
              { header: "access-control-allow-methods", operation: "set", value: "GET, POST, PUT, DELETE, PATCH, OPTIONS, HEAD" },
              { header: "access-control-allow-headers", operation: "set", value: "*" },
              { header: "access-control-allow-credentials", operation: "set", value: "true" },
            ],
          },
          condition: {
            initiatorDomains: [chrome.runtime.id],
            resourceTypes: ["xmlhttprequest"],
          },
        },
      ],
    });
  } catch (e) {
    // ignore
  }
}

chrome.runtime.onInstalled.addListener(setupReplayCORSRule);
chrome.runtime.onStartup?.addListener(setupReplayCORSRule);
setupReplayCORSRule();



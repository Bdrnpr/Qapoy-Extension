/* ============================================================
   qaopy – panel.js
   Network request capture, display and QA panel
   ============================================================ */

"use strict";

// ── State ─────────────────────────────────────────────────────
const requests    = [];
let   activeFilter = "all";       // "all" | "fetch-xhr"
let   searchQuery  = "";
let   activeRowEl  = null;        // currently highlighted <tr>
// key = URL string → { ruleId, body, status }
let   activeMocks  = {};

// ── DOM refs ──────────────────────────────────────────────────
const tbody      = document.getElementById("req-body");
const selectAll      = document.getElementById("select-all");
const btnDownload    = document.getElementById("btn-download");
const btnDownloadUrls= document.getElementById("btn-download-urls");
const btnClear       = document.getElementById("btn-clear");
const searchBox  = document.getElementById("search-box");
const reqCount   = document.getElementById("req-count");
const emptyState = document.getElementById("empty-state");
const toast      = document.getElementById("toast");

// Mock modal refs
const mockOverlay     = document.getElementById("mock-overlay");
const mockUrlInput    = document.getElementById("mock-url");
const mockStatusSel   = document.getElementById("mock-status");
const mockBodyInput   = document.getElementById("mock-body");
const mockActivateBtn = document.getElementById("mock-activate-btn");
const mockClearBtn    = document.getElementById("mock-clear-btn");
const mockCloseBtn    = document.getElementById("mock-close");

// ── Toast ─────────────────────────────────────────────────────
let toastTimer = null;
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

// ── Clipboard ─────────────────────────────────────────────────
function copyText(text, label) {
  navigator.clipboard.writeText(text)
    .then(() => showToast(`✓ ${label} copied`))
    .catch(() => {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.cssText = "position:fixed;opacity:0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      showToast(`✓ ${label} copied`);
    });
}

// ── Utilities ─────────────────────────────────────────────────
function isFetchXHR(entry) {
  if (!entry) return false;

  // 1. Chrome DevTools resourceType (exact match with Chrome Network tab)
  const type = (entry._resourceType || "").toLowerCase();
  if (type) {
    return type === "xhr" || type === "fetch";
  }

  // 2. Initiator fallback
  const initType = (entry._initiator?.type || "").toLowerCase();
  if (initType === "fetch" || initType === "xmlhttprequest") return true;

  // 3. Header fallback
  const xrw = entry.request?.headers?.find(h => h.name.toLowerCase() === "x-requested-with")?.value || "";
  if (xrw.toLowerCase() === "xmlhttprequest") return true;

  return false;
}

function methodClass(m) {
  return ["GET","POST","PUT","DELETE","PATCH"].includes(m) ? `method-${m}` : "method-OTHER";
}

function statusClass(code) {
  if (!code || code === 0) return "s0";
  if (code < 300) return "s2xx";
  if (code < 400) return "s3xx";
  if (code < 500) return "s4xx";
  return "s5xx";
}

function prettyJSON(str) {
  try { return JSON.stringify(JSON.parse(str), null, 2); }
  catch { return str || ""; }
}

function getUrlPath(urlStr) {
  if (!urlStr) return "";
  try {
    const u = new URL(urlStr);
    return (u.pathname || "/") + (u.search || "");
  } catch {
    return urlStr;
  }
}

function getRequestBody(entry) {
  return entry.request?.postData?.text || "";
}

function getResponseBody(entry) {
  return entry.response?.content?.text || "";
}

function buildCURL(entry) {
  const { request } = entry;
  let cmd = `curl -X ${request.method} '${request.url}'`;
  const skip = new Set(["content-length","host"]);
  request.headers.forEach(h => {
    if (!skip.has(h.name.toLowerCase()))
      cmd += ` \\\n  -H '${h.name}: ${h.value.replace(/'/g, "\\'")}'`;
  });
  const body = getRequestBody(entry);
  if (body) cmd += ` \\\n  --data-raw '${body.replace(/'/g, "\\'")}'`;
  return cmd;
}

function buildPlaywright(entry) {
  const req    = entry.request  || {};
  const method = (req.method || "GET").toLowerCase();
  const url    = req.url || "";

  // Keep only meaningful headers – skip:
  // 1. HTTP/2 pseudo-headers   (:authority, :method, :path, :scheme …)
  // 2. cookie / analytics junk (always noisy, rarely needed in API tests)
  // 3. Browser-internal headers that Playwright injects itself
  const skipHeaders = new Set([
    "cookie",
    "content-length", "host", "connection", "accept-encoding",
    "sec-ch-ua", "sec-ch-ua-mobile", "sec-ch-ua-platform",
    "sec-fetch-dest", "sec-fetch-mode", "sec-fetch-site",
    "upgrade-insecure-requests",
  ]);

  const headers = {};
  (req.headers || []).forEach(h => {
    const nameLower = h.name.toLowerCase();
    // Drop HTTP/2 pseudo-headers (:authority, :method, :path, :scheme)
    if (h.name.startsWith(":")) return;
    // Drop blocked set
    if (skipHeaders.has(nameLower)) return;
    headers[h.name] = h.value;
  });

  const bodyRaw = getRequestBody(entry);
  let bodyParsed = null;
  if (bodyRaw) {
    try   { bodyParsed = JSON.parse(bodyRaw); }
    catch { bodyParsed = bodyRaw; }
  }

  // Build options object
  const options = {};
  if (Object.keys(headers).length > 0) options.headers = headers;
  if (bodyParsed !== null) options.data = bodyParsed;

  const optionsStr = Object.keys(options).length > 0
    ? `, ${JSON.stringify(options, null, 2).replace(/^/gm, "  ").trimStart()}`
    : "";

  return [
    `// Playwright API Test – auto-generated by qaopy`,
    `const response = await request.${method}('${url}'${optionsStr});`,
    `const body = await response.json();`,
    ``,
    `expect(response.status()).toBe(${entry.response?.status || 200});`,
    `console.log(body);`,
  ].join("\n");
}

async function copyAsPlaywright(entry) {
  const code = buildPlaywright(entry);
  try {
    await navigator.clipboard.writeText(code);
    showToast("🎭 Playwright code copied! (Ctrl+V)");
  } catch (err) {
    showToast(`⚠ Clipboard error: ${err.message}`);
  }
}

function formatEntry(entry, pretty) {
  const req  = entry.request  || {};
  const resp = entry.response || {};
  let reqBody  = getRequestBody(entry);
  let respBody = getResponseBody(entry);
  if (pretty) { reqBody = prettyJSON(reqBody); respBody = prettyJSON(respBody); }
  const sep = "─".repeat(60);
  return [
    `URL: ${req.url || ""}`, sep,
    `Method : ${req.method || ""}`,
    `Status : ${resp.status || ""} ${resp.statusText || ""}`, sep,
    "Request:", reqBody || "(empty)", sep,
    "Response:", respBody || "(empty)",
  ].join("\n");
}

// ── Filter & render ───────────────────────────────────────────
function matchesFilter(entry) {
  if (activeFilter === "fetch-xhr" && !isFetchXHR(entry)) return false;
  if (searchQuery && !(entry.request?.url || "").toLowerCase().includes(searchQuery)) return false;
  return true;
}

function filteredRequests() {
  return requests.filter(matchesFilter);
}

let incomingQueue = [];
let incomingRafId = null;

function processIncomingQueue() {
  incomingRafId = null;
  if (!incomingQueue.length) return;

  const batch = incomingQueue;
  incomingQueue = [];

  const fragment = document.createDocumentFragment();
  let addedCount = 0;

  for (let i = 0; i < batch.length; i++) {
    const entry = batch[i];
    if (matchesFilter(entry)) {
      fragment.appendChild(buildRow(entry));
      addedCount++;
    }
  }

  if (addedCount > 0) {
    if (emptyState) emptyState.style.display = "none";
    tbody.appendChild(fragment);
  }

  const visibleCount = tbody.querySelectorAll("tr").length;
  if (reqCount) {
    reqCount.textContent = `${visibleCount} request${visibleCount !== 1 ? "s" : ""}`;
  }
}

function addIncomingRequest(entry) {
  requests.push(entry);
  incomingQueue.push(entry);
  if (!incomingRafId) {
    incomingRafId = requestAnimationFrame(processIncomingQueue);
  }
}

function render() {
  if (incomingRafId) {
    cancelAnimationFrame(incomingRafId);
    incomingRafId = null;
  }
  incomingQueue = [];

  const visible = filteredRequests();
  emptyState.style.display = visible.length === 0 ? "flex" : "none";
  reqCount.textContent     = `${visible.length} request${visible.length !== 1 ? "s" : ""}`;
  tbody.innerHTML = "";
  visible.forEach(entry => tbody.appendChild(buildRow(entry)));
}

// ── Mock Response ─────────────────────────────────────────────
let _mockCurrentEntry = null;

function openMockModal(entry, _tr) {
  _mockCurrentEntry = entry;
  const url = entry.request?.url || "";

  mockUrlInput.value  = url;
  mockBodyInput.value = activeMocks[url]?.body ?? (getResponseBody(entry) || "{}");
  const savedStatus   = activeMocks[url]?.status;
  mockStatusSel.value = String(savedStatus || entry.response?.status || "200");

  const isMocked = !!activeMocks[url];
  mockClearBtn.style.display    = isMocked ? "inline-flex" : "none";
  mockActivateBtn.textContent   = isMocked ? "✅ Update Mock" : "🔴 Activate Mock";
  mockActivateBtn.classList.toggle("active-mock", isMocked);

  mockOverlay.style.display = "flex";
  mockBodyInput.focus();
}

function closeMockModal() {
  mockOverlay.style.display = "none";
  _mockCurrentEntry = null;
}

async function activateMock() {
  const url    = mockUrlInput.value.trim();
  const body   = mockBodyInput.value.trim();
  const status = parseInt(mockStatusSel.value, 10) || 200;

  if (!url) { showToast("⚠ URL is required"); return; }

  mockActivateBtn.disabled    = true;
  mockActivateBtn.textContent = "⏳ Activating…";

  try {
    const resp = await new Promise((resolve, reject) => {
      if (!chrome.runtime?.sendMessage) { reject(new Error("Extension runtime unavailable")); return; }
      chrome.runtime.sendMessage({ type: "SET_MOCK", url, body, status }, r => {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        resolve(r);
      });
    });

    if (!resp?.ok) throw new Error(resp?.error || "Unknown error");

    activeMocks[url] = { ruleId: resp.ruleId, body, status };
    render(); // refresh table badges
    closeMockModal();
    showToast(`🔴 Mock active → ${new URL(url).pathname}`);
  } catch (err) {
    showToast(`⚠ Mock failed: ${err.message}`);
  } finally {
    mockActivateBtn.disabled    = false;
    mockActivateBtn.textContent = "🔴 Activate Mock";
  }
}

async function clearMock() {
  const url = mockUrlInput.value.trim();
  if (!url || !activeMocks[url]) { closeMockModal(); return; }

  mockClearBtn.disabled    = true;
  mockClearBtn.textContent = "⏳ Clearing…";

  try {
    const resp = await new Promise((resolve, reject) => {
      if (!chrome.runtime?.sendMessage) { reject(new Error("Extension runtime unavailable")); return; }
      chrome.runtime.sendMessage({ type: "CLEAR_MOCK", url }, r => {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        resolve(r);
      });
    });

    if (!resp?.ok) throw new Error(resp?.error || "Unknown error");

    delete activeMocks[url];
    render();
    closeMockModal();
    showToast(`✓ Mock cleared → ${new URL(url).pathname}`);
  } catch (err) {
    showToast(`⚠ Clear failed: ${err.message}`);
  } finally {
    mockClearBtn.disabled    = false;
    mockClearBtn.textContent = "✕ Clear Mock";
  }
}

// Load existing mocks from background on startup
function loadMocksFromBackground() {
  if (!chrome.runtime?.sendMessage) return;
  chrome.runtime.sendMessage({ type: "GET_MOCKS" }, resp => {
    if (chrome.runtime.lastError || !resp?.ok) return;
    activeMocks = resp.mocks || {};
    render();
  });
}

// Wire up mock modal buttons
if (mockActivateBtn) mockActivateBtn.addEventListener("click", activateMock);
if (mockClearBtn)    mockClearBtn.addEventListener("click",    clearMock);
if (mockCloseBtn)    mockCloseBtn.addEventListener("click",    closeMockModal);
if (mockOverlay)     mockOverlay.addEventListener("click", e => { if (e.target === mockOverlay) closeMockModal(); });

// ── Build table row ───────────────────────────────────────────
function buildRow(entry) {
  const req    = entry.request  || {};
  const resp   = entry.response || {};
  const method = (req.method || "?").toUpperCase();
  const status = resp.status || 0;
  const url    = req.url || "";

  const tr = document.createElement("tr");
  if (entry._selected)  tr.classList.add("selected");
  if (entry._activeRow) tr.classList.add("row-active");
  if (status >= 400 && status < 500) tr.classList.add("row-error-4xx");
  if (status >= 500) tr.classList.add("row-error-5xx");
  if (activeMocks[url])  tr.classList.add("row-mocked");

  // ── Checkbox
  const tdCb = document.createElement("td");
  tdCb.className = "col-cb";
  const cb = document.createElement("input");
  cb.type = "checkbox"; cb.className = "row-cb"; cb.checked = !!entry._selected;
  cb.addEventListener("change", e => {
    e.stopPropagation();
    entry._selected = cb.checked;
    tr.classList.toggle("selected", cb.checked);
    syncSelectAll();
  });
  tdCb.appendChild(cb);
  tr.appendChild(tdCb);

  // ── URL
  const tdU = document.createElement("td");
  tdU.className = "url-cell col-url";
  tdU.title = url;
  if (activeMocks[url]) {
    const urlWrap = document.createElement("span");
    urlWrap.style.cssText = "display:flex;align-items:center;gap:5px;min-width:0";
    const mockBadge = document.createElement("span");
    mockBadge.className   = "mock-badge";
    mockBadge.textContent = "🔴 MOCK";
    const urlText = document.createElement("span");
    urlText.style.cssText = "overflow:hidden;text-overflow:ellipsis;white-space:nowrap";
    urlText.textContent   = getUrlPath(url);
    urlWrap.appendChild(mockBadge);
    urlWrap.appendChild(urlText);
    tdU.appendChild(urlWrap);
  } else {
    tdU.textContent = getUrlPath(url);
  }
  tr.appendChild(tdU);

  // ── Status
  const tdS = document.createElement("td");
  tdS.className = "col-status";
  const sc = document.createElement("span");
  sc.className  = `status-code ${statusClass(status)}`;
  sc.textContent = status || "—";
  tdS.appendChild(sc);
  tr.appendChild(tdS);

  // ── Method
  const tdM = document.createElement("td");
  tdM.className = "col-method";
  const badge = document.createElement("span");
  badge.className = `method-badge ${methodClass(method)}`;
  badge.textContent = method;
  tdM.appendChild(badge);
  tr.appendChild(tdM);

  // ── Actions
  const tdA = document.createElement("td");
  tdA.className = "actions-cell col-actions";

  // Kebab
  const kebabWrap = document.createElement("div");
  kebabWrap.className = "kebab-wrap";

  const kebabBtn = document.createElement("button");
  kebabBtn.className   = "kebab-btn";
  kebabBtn.title       = "More options";
  kebabBtn.textContent = "⋮";
  kebabBtn.setAttribute("aria-haspopup", "true");
  kebabBtn.setAttribute("aria-expanded", "false");

  const menu = document.createElement("div");
  menu.className = "kebab-menu";
  menu.setAttribute("role", "menu");

  const items = [
    { label: "Copy All",               icon: "📋", action: () => copyText(formatEntry(entry, false), "All") },
    { label: "Copy Beauty (JSON)",     icon: "✨", action: () => copyText(formatEntry(entry, true),  "Formatted") },
    { label: "Copy cURL",              icon: "⌘",  action: () => copyText(buildCURL(entry),             "cURL") },
    { label: "Copy Request",           icon: "↑",  action: () => copyText(getRequestBody(entry) || url, "Request") },
    { label: "Copy Response",          icon: "↓",  action: () => copyText(getResponseBody(entry),       "Response") },
    { label: "Replay / Resend",        icon: "🚀", action: () => openDrawer(entry, tr, "replay") },
    { label: "Mock Response",          icon: "🔴", action: () => openMockModal(entry, tr) },
    { label: "Download Bug Evidence",  icon: "📸", action: () => downloadBugEvidence(entry) },
    { label: "Copy as Playwright",     icon: "🎭",  action: () => copyAsPlaywright(entry) },
  ];

  items.forEach((item, i) => {
    if (i > 0) { const sep = document.createElement("div"); sep.className = "kebab-divider"; menu.appendChild(sep); }
    const btn = document.createElement("button");
    btn.className = "kebab-item";
    btn.setAttribute("role", "menuitem");
    btn.innerHTML = `<span class="icon">${item.icon}</span>${item.label}`;
    btn.addEventListener("click", e => { e.stopPropagation(); item.action(); closeKebab(); });
    menu.appendChild(btn);
  });

  kebabBtn.addEventListener("click", e => {
    e.stopPropagation();
    const isOpen = menu.classList.contains("open");
    closeKebab();
    if (!isOpen) openKebab(menu, kebabBtn);
  });

  kebabWrap.appendChild(kebabBtn);
  kebabWrap.appendChild(menu);

  tdA.appendChild(kebabWrap);
  tr.appendChild(tdA);

  // ── ROW CLICK → open drawer ──────────────────────────────────
  tr.addEventListener("click", e => {
    if (e.target.closest(".row-cb,.row-btn,.kebab-wrap")) return;
    openDrawer(entry, tr);
  });

  return tr;
}

// ── Kebab open/close ──────────────────────────────────────────
function openKebab(menu, btn) {
  menu.classList.add("open");
  btn.setAttribute("aria-expanded", "true");
  const rect = btn.getBoundingClientRect();
  const w    = 200;
  let left   = rect.right - w;
  if (left < 4) left = 4;
  if (left + w > window.innerWidth - 4) left = window.innerWidth - w - 4;
  menu.style.left = left + "px";

  const menuHeight = menu.offsetHeight || 220;
  const spaceBelow = window.innerHeight - rect.bottom;
  const spaceAbove = rect.top;

  if (spaceBelow < menuHeight + 8 && spaceAbove > spaceBelow) {
    // Open upwards
    let top = rect.top - menuHeight - 4;
    if (top < 4) top = 4;
    menu.style.top = top + "px";
  } else {
    // Open downwards
    let top = rect.bottom + 4;
    if (top + menuHeight > window.innerHeight - 4) {
      top = Math.max(4, window.innerHeight - menuHeight - 4);
    }
    menu.style.top = top + "px";
  }
}
function closeKebab() {
  document.querySelectorAll(".kebab-menu.open").forEach(m => {
    m.classList.remove("open");
    const b = m.previousElementSibling;
    if (b) b.setAttribute("aria-expanded", "false");
  });
}
document.addEventListener("click",   e => { if (!e.target.closest(".kebab-wrap")) closeKebab(); });
document.addEventListener("keydown",  e => { if (e.key === "Escape") closeKebab(); });

// ── Select-all ────────────────────────────────────────────────
function syncSelectAll() {
  if (!selectAll) return;
  const visible = filteredRequests();
  const sel     = visible.filter(e => e._selected).length;
  selectAll.checked       = sel > 0 && sel === visible.length;
  selectAll.indeterminate = sel > 0 && sel < visible.length;
}
if (selectAll) {
  selectAll.addEventListener("change", () => {
    const state = selectAll.checked;
    filteredRequests().forEach(e => (e._selected = state));
    render();
  });
}

// ── Download selected ─────────────────────────────────────────
if (btnDownload) {
  btnDownload.addEventListener("click", () => {
    const sel = requests.filter(e => e._selected);
    if (!sel.length) { showToast("⚠ No requests selected"); return; }
    const sep  = "═".repeat(70);
    const text = sel.map((entry, i) => {
      const req  = entry.request  || {};
      const resp = entry.response || {};
      return [
        `[${i+1}] ${req.method||""} ${resp.status||""}`,
        `URL: ${req.url||""}`, "",
        "Request:",  getRequestBody(entry)  || "(empty)", "",
        "Response:", getResponseBody(entry) || "(empty)", sep,
      ].join("\n");
    }).join("\n\n");

    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `qaopy-export-${Date.now()}.txt`;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(a.href);
    showToast(`✓ Exported ${sel.length} request(s)`);
  });
}

// ── Download selected URLs ────────────────────────────────────
if (btnDownloadUrls) {
  btnDownloadUrls.addEventListener("click", () => {
    const sel = requests.filter(e => e._selected);
    if (!sel.length) { showToast("⚠ No requests selected"); return; }
    const urls = sel.map(entry => entry.request?.url || "").filter(Boolean);
    if (!urls.length) { showToast("⚠ No URLs found in selected requests"); return; }
    const text = urls.join("\n") + "\n";

    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `qaopy-urls-${Date.now()}.txt`;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(a.href);
    showToast(`✓ Exported ${urls.length} URL(s)`);
  });
}

// ── Download File Helper ──────────────────────────────────────
function downloadFile(urlOrBlob, filename) {
  const isString = typeof urlOrBlob === "string";
  const url = isString ? urlOrBlob : URL.createObjectURL(urlOrBlob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  if (!isString) {
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

// ── Download Bug Evidence (PNG Screenshot + Detailed TXT Log) ─
async function downloadBugEvidence(entry) {
  if (!entry) return;

  const req  = entry.request  || {};
  const resp = entry.response || {};
  const method = (req.method || "REQ").toUpperCase();

  let endpoint = "request";
  try {
    const u = new URL(req.url);
    const cleanPath = u.pathname.replace(/^\/+|\/+$/g, "").replace(/[^a-zA-Z0-9_-]+/g, "_");
    endpoint = cleanPath || u.hostname.replace(/[^a-zA-Z0-9_-]+/g, "_");
  } catch {}

  const now = new Date();
  const pad = n => String(n).padStart(2, "0");
  const timeStr  = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  const fileTime = `${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
  const baseName = `qaopy-evi-${endpoint}_${fileTime}`;

  showToast("⏳ Generating bug evidence...");

  // 1. Build Comprehensive TXT Log Report
  const sep     = "═".repeat(72);
  const subSep  = "─".repeat(72);
  const reqHeaders  = (req.headers || []).map(h => `${h.name}: ${h.value}`).join("\n") || "(none)";
  const respHeaders = (resp.headers || []).map(h => `${h.name}: ${h.value}`).join("\n") || "(none)";
  const reqBody     = prettyJSON(getRequestBody(entry)) || "(empty)";
  const respBody    = prettyJSON(getResponseBody(entry)) || "(empty)";
  const curlCmd     = buildCURL(entry);

  const reportText = [
    sep,
    "QAOPY BUG EVIDENCE REPORT",
    sep,
    `Captured At  : ${timeStr}`,
    `Method       : ${method}`,
    `Status       : ${resp.status || ""} ${resp.statusText || ""}`,
    `URL          : ${req.url || ""}`,
    `Duration     : ${Math.round(entry.time || 0)} ms`,
    "",
    subSep,
    "REQUEST HEADERS",
    subSep,
    reqHeaders,
    "",
    subSep,
    "RESPONSE HEADERS",
    subSep,
    respHeaders,
    "",
    subSep,
    "REQUEST BODY",
    subSep,
    reqBody,
    "",
    subSep,
    "RESPONSE BODY",
    subSep,
    respBody,
    "",
    subSep,
    "cURL REPRODUCTION COMMAND",
    subSep,
    curlCmd,
    sep,
  ].join("\n");

  const txtBlob = new Blob([reportText], { type: "text/plain;charset=utf-8" });
  downloadFile(txtBlob, `${baseName}.txt`);

  // 2. Capture Screenshot & Download PNG
  const tabId = chrome?.devtools?.inspectedWindow?.tabId || null;
  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: "TAKE_SCREENSHOT", tabId }, res => {
      if (res && res.ok && res.dataUrl) {
        setTimeout(() => {
          downloadFile(res.dataUrl, `${baseName}.png`);
          showToast("✓ Bug evidence saved (PNG + TXT)!");
        }, 150);
      } else {
        showToast("✓ Log TXT saved!");
      }
    });
  } else {
    showToast("✓ Log TXT saved!");
  }
}

// ── Instant Screenshot -> Clipboard (Zero Dialog / Fast) ─────
function captureScreenshotToClipboard() {
  const btn = document.getElementById("btn-screenshot");
  if (btn) {
    btn.disabled = true;
    btn.textContent = "⏳ Snapping...";
  }

  if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) {
    if (btn) { btn.disabled = false; btn.textContent = "📷 Screenshot"; }
    showToast("⚠ Please reload the extension");
    return;
  }

  const tabId = chrome?.devtools?.inspectedWindow?.tabId || null;

  chrome.runtime.sendMessage({ type: "TAKE_SCREENSHOT", tabId }, async res => {
    if (btn) {
      btn.disabled = false;
      btn.textContent = "📷 Screenshot";
    }

    if (chrome.runtime.lastError) {
      showToast(`⚠ ${chrome.runtime.lastError.message}`);
      return;
    }

    if (!res || !res.ok || !res.dataUrl) {
      showToast(`⚠ Screenshot failed: ${res?.error || "Error"}`);
      return;
    }

    try {
      const response = await fetch(res.dataUrl);
      const blob = await response.blob();

      await navigator.clipboard.write([
        new ClipboardItem({ "image/png": blob })
      ]);
      showToast("✓ Copied to clipboard! (Ctrl+V)");
    } catch (clipErr) {
      showToast(`⚠ Clipboard error: ${clipErr.message}`);
    }
  });
}

safeClick("btn-screenshot", captureScreenshotToClipboard);

// ── Clear ─────────────────────────────────────────────────────
if (btnClear) {
  btnClear.addEventListener("click", () => {
    requests.length = 0;
    closeDrawer();
    render();
    showToast("✓ Log cleared");
  });
}

// ── Filter buttons ────────────────────────────────────────────
document.querySelectorAll(".filter-group .filter-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".filter-group .filter-btn").forEach(b => {
      b.classList.remove("active"); b.setAttribute("aria-selected","false");
    });
    btn.classList.add("active"); btn.setAttribute("aria-selected","true");
    activeFilter = btn.dataset.filter;
    render();
  });
});

// ── View Columns (Toggle column visibility) ───────────────────
const btnViewCols      = document.getElementById("btn-view-cols");
const viewColsDropdown = document.getElementById("view-cols-dropdown");
const reqTable         = document.getElementById("req-table");

const COLUMN_KEYS = ["cb", "url", "status", "method", "actions"];

function loadColumnPreferences() {
  let prefs = null;
  try {
    prefs = JSON.parse(localStorage.getItem("qaopy_columns"));
  } catch {}

  if (!prefs || typeof prefs !== "object") {
    prefs = { cb: true, url: true, status: true, method: true, actions: true };
  }

  COLUMN_KEYS.forEach(col => {
    const isVisible = prefs[col] !== false;
    const input = document.getElementById(`toggle-col-${col}`);
    if (input) input.checked = isVisible;
    if (reqTable) reqTable.classList.toggle(`hide-col-${col}`, !isVisible);
  });
}

function saveColumnPreferences() {
  const prefs = {};
  COLUMN_KEYS.forEach(col => {
    const input = document.getElementById(`toggle-col-${col}`);
    prefs[col] = input ? input.checked : true;
    if (reqTable) reqTable.classList.toggle(`hide-col-${col}`, !prefs[col]);
  });
  try {
    localStorage.setItem("qaopy_columns", JSON.stringify(prefs));
  } catch {}
}

if (btnViewCols && viewColsDropdown) {
  btnViewCols.addEventListener("click", e => {
    e.stopPropagation();
    const isClosed = viewColsDropdown.style.display === "none";
    viewColsDropdown.style.display = isClosed ? "block" : "none";
    btnViewCols.classList.toggle("active", isClosed);
  });

  document.addEventListener("click", e => {
    if (!viewColsDropdown.contains(e.target) && e.target !== btnViewCols) {
      viewColsDropdown.style.display = "none";
      btnViewCols.classList.remove("active");
    }
  });

  COLUMN_KEYS.forEach(col => {
    const input = document.getElementById(`toggle-col-${col}`);
    if (input) {
      input.addEventListener("change", () => {
        saveColumnPreferences();
      });
    }
  });
}

loadColumnPreferences();

// ── Search ────────────────────────────────────────────────────
if (searchBox) {
  searchBox.addEventListener("input", () => {
    searchQuery = searchBox.value.trim().toLowerCase();
    render();
  });
}

// ── Network listener ──────────────────────────────────────────
chrome.devtools.network.onRequestFinished.addListener(entry => {
  if (!entry) return;
  if (!entry.response) entry.response = {};
  if (!entry.response.content) entry.response.content = {};

  // Append incrementally without destroying the table!
  addIncomingRequest(entry);

  try {
    entry.getContent((body, encoding) => {
      entry.response.content.text = (encoding === "base64") ? "[binary content]" : (body || "");
      if (entry._activeRow && preResp) {
        renderPre(preResp, entry.response.content.text);
      }
    });
  } catch (e) {
    console.warn("[qaopy] getContent error:", e);
  }
});

// ── Initial render ────────────────────────────────────────────
render();

// ═══════════════════════════════════════════════════════════════
//  DETAIL DRAWER
// ═══════════════════════════════════════════════════════════════

const drawerEl   = document.getElementById("drawer");
const dwMethod   = document.getElementById("dw-method");
const dwStatus   = document.getElementById("dw-status");
const dwUrl      = document.getElementById("dw-url");
const closeBtn   = document.getElementById("drawer-close-btn");

// Tab elements
const dwTabs     = document.querySelectorAll(".dw-tab");
const dwPanels   = document.querySelectorAll(".dw-panel");

// Content pres
const preGeneral = document.getElementById("content-general");
const preReqHdr  = document.getElementById("content-req-headers");
const preRespHdr = document.getElementById("content-resp-headers");
const preReq     = document.getElementById("content-request");
const preResp    = document.getElementById("content-response");

// Helper for safe click binding
function safeClick(id, handler) {
  const el = document.getElementById(id);
  if (el) el.addEventListener("click", handler);
}

// Copy buttons & their raw-text stores
const copyStore  = { general: "", "req-headers": "", "resp-headers": "", request: "", response: "" };

safeClick("copy-general",      () => copyText(copyStore["general"],      "General Headers"));
safeClick("copy-req-headers",   () => copyText(copyStore["req-headers"],  "Request Headers"));
safeClick("copy-resp-headers",  () => copyText(copyStore["resp-headers"], "Response Headers"));
safeClick("copy-request",       () => copyText(copyStore["request"],      "Request Body"));
safeClick("copy-response",      () => copyText(copyStore["response"],     "Response Body"));

// ── Tab switching ─────────────────────────────────────────────
let currentActiveTab = "headers";

dwTabs.forEach(tab => {
  tab.addEventListener("click", () => {
    currentActiveTab = tab.dataset.tab;
    dwTabs.forEach(t  => { t.classList.remove("active"); t.setAttribute("aria-selected","false"); });
    dwPanels.forEach(p => p.classList.remove("active"));
    tab.classList.add("active"); tab.setAttribute("aria-selected","true");
    const target = document.getElementById("panel-" + tab.dataset.tab);
    if (target) target.classList.add("active");
  });
});

// ── JSON highlighter ──────────────────────────────────────────
function highlightJSON(json) {
  const esc = json
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
  return esc.replace(
    /("(\\u[a-fA-F0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?|[{}\[\]])/g,
    m => {
      if (/^[{}\[\]]/.test(m))  return `<span class="hl-brace">${m}</span>`;
      if (/^"/.test(m)) {
        if (/:$/.test(m))       return `<span class="hl-key">${m.slice(0,-1)}</span><span class="hl-colon">:</span>`;
        return `<span class="hl-str">${m}</span>`;
      }
      if (/true|false/.test(m)) return `<span class="hl-bool">${m}</span>`;
      if (/null/.test(m))       return `<span class="hl-null">${m}</span>`;
      return `<span class="hl-num">${m}</span>`;
    }
  );
}

// ── renderPre: fill a <pre> with JSON highlight or plain text ─
function renderPre(pre, rawText) {
  if (!rawText) {
    pre.textContent = "(empty)";
    pre.classList.add("empty");
    return;
  }
  pre.classList.remove("empty");
  try {
    const pretty = JSON.stringify(JSON.parse(rawText), null, 2);
    pre.innerHTML = highlightJSON(pretty);
  } catch {
    pre.textContent = rawText;
  }
}

// ── renderHeaders: build a clean key:value table ──────────────
function renderHeaders(pre, headers) {
  if (!headers || !headers.length) {
    pre.textContent = "(none)";
    pre.classList.add("empty");
    return;
  }
  pre.classList.remove("empty");
  const table = document.createElement("table");
  table.className = "hdr-table";
  headers.forEach(h => {
    const tr = document.createElement("tr");
    const tdN = document.createElement("td"); tdN.className = "hdr-name";  tdN.textContent = h.name;
    const tdV = document.createElement("td"); tdV.className = "hdr-value";
    if (h.isStatus && h.statusCode !== undefined) {
      const s = h.statusCode;
      const dotType = s >= 200 && s < 300 ? "dot-2xx"
                    : s >= 300 && s < 400 ? "dot-3xx"
                    : s >= 400 && s < 500 ? "dot-4xx"
                    : s >= 500 ? "dot-5xx"
                    : "dot-0";
      tdV.innerHTML = `<span class="hdr-status-badge"><span class="dw-status-dot ${dotType}"></span><span class="status-code ${statusClass(s)}">${h.value}</span></span>`;
    } else {
      tdV.textContent = h.value;
    }
    tr.appendChild(tdN); tr.appendChild(tdV);
    table.appendChild(tr);
  });
  pre.innerHTML = "";
  pre.appendChild(table);
}

// ── openDrawer(entry, trEl) ───────────────────────────────────
// Replay DOM refs
const replayMethodInput   = document.getElementById("replay-method");
const replayUrlInput      = document.getElementById("replay-url");
const replaySendBtn       = document.getElementById("replay-send-btn");
const replayHeadersInput  = document.getElementById("replay-headers-input");
const replayBodyInput     = document.getElementById("replay-body-input");
const replayBeautyBtn     = document.getElementById("replay-beauty-btn");
const replayResContainer  = document.getElementById("replay-response-container");
const replayResStatus     = document.getElementById("replay-res-status");
const replayResTime       = document.getElementById("replay-res-time");
const replayResBody       = document.getElementById("replay-response-body");
const replayCopyBtn       = document.getElementById("replay-copy-response");

let replayLastResponseText = "";

const FORBIDDEN_HEADERS = new Set([
  "accept-charset",
  "accept-encoding",
  "access-control-request-headers",
  "access-control-request-method",
  "connection",
  "content-length",
  "cookie",
  "cookie2",
  "date",
  "dnt",
  "expect",
  "host",
  "keep-alive",
  "origin",
  "referer",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade",
  "via"
]);

function isSafeHeader(name) {
  if (!name) return false;
  const lower = name.toLowerCase().trim();
  if (lower.startsWith(":") || lower.startsWith("sec-") || lower.startsWith("proxy-")) {
    return false;
  }
  return !FORBIDDEN_HEADERS.has(lower);
}

// ── openDrawer(entry, trEl, initialTab) ───────────────────────
function openDrawer(entry, trEl, initialTab = null) {
  const req  = entry.request  || {};
  const resp = entry.response || {};
  const activeTabName = initialTab || currentActiveTab || "headers";
  if (initialTab) {
    currentActiveTab = initialTab;
  }

  // Header bar
  const method = (req.method || "?").toUpperCase();
  if (dwMethod) {
    dwMethod.textContent  = method;
    dwMethod.className    = `method-badge ${methodClass(method)}`;
  }
  if (dwStatus) {
    const s = resp.status || 0;
    const dotType = s >= 200 && s < 300 ? "dot-2xx"
                  : s >= 300 && s < 400 ? "dot-3xx"
                  : s >= 400 && s < 500 ? "dot-4xx"
                  : s >= 500 ? "dot-5xx"
                  : "dot-0";
    dwStatus.innerHTML = `<span class="dw-status-dot ${dotType}"></span><span class="status-code ${statusClass(s)}">${s ? `${s} ${resp.statusText || ""}` : "—"}</span>`;
  }

  if (dwUrl) {
    dwUrl.textContent     = getUrlPath(req.url || "");
    dwUrl.title           = req.url || "";
  }

  // ── General Headers section
  const generalHeaders = [
    { name: "Request URL",    value: req.url || "" },
    { name: "Request Method", value: method },
    { name: "Status Code",    value: resp.status ? `${resp.status} ${resp.statusText || ""}` : "—", isStatus: true, statusCode: resp.status || 0 },
  ];
  copyStore["general"] = generalHeaders.map(h => `${h.name}: ${h.value}`).join("\n");
  renderHeaders(preGeneral, generalHeaders);

  // ── Request Headers tab content
  const reqHeaders  = req.headers  || [];
  const respHeaders = resp.headers || [];
  copyStore["req-headers"]  = reqHeaders.map(h  => `${h.name}: ${h.value}`).join("\n");
  copyStore["resp-headers"] = respHeaders.map(h => `${h.name}: ${h.value}`).join("\n");
  renderHeaders(preReqHdr,  reqHeaders);
  renderHeaders(preRespHdr, respHeaders);

  // ── Request body tab content (copy beauty formatted)
  const reqBody = getRequestBody(entry);
  copyStore["request"] = prettyJSON(reqBody);
  renderPre(preReq, reqBody);

  // ── Response body tab content (copy beauty formatted)
  const respBody = getResponseBody(entry);
  copyStore["response"] = prettyJSON(respBody);
  renderPre(preResp, respBody);

  // ── Replay prefill
  if (replayMethodInput) replayMethodInput.value = method;
  if (replayUrlInput) replayUrlInput.value = req.url || "";
  const filterHdrs = reqHeaders.filter(h => isSafeHeader(h.name));
  if (replayHeadersInput) replayHeadersInput.value = filterHdrs.map(h => `${h.name}: ${h.value}`).join("\n");
  if (replayBodyInput) replayBodyInput.value = prettyJSON(reqBody);
  if (replayResContainer) replayResContainer.style.display = "none";
  replayLastResponseText = "";

  // Switch to active tab
  dwTabs.forEach(t  => { t.classList.remove("active"); t.setAttribute("aria-selected","false"); });
  dwPanels.forEach(p => p.classList.remove("active"));
  const targetTab = document.querySelector(`.dw-tab[data-tab="${activeTabName}"]`) || document.querySelector('.dw-tab[data-tab="headers"]');
  if (targetTab) { targetTab.classList.add("active"); targetTab.setAttribute("aria-selected","true"); }
  const targetPanel = document.getElementById("panel-" + (targetTab ? targetTab.dataset.tab : "headers"));
  if (targetPanel) targetPanel.classList.add("active");

  // Highlight active row (ensure only the clicked row is active)
  requests.forEach(r => { r._activeRow = false; });
  document.querySelectorAll("#req-body tr.row-active").forEach(el => el.classList.remove("row-active"));
  entry._activeRow = true;
  trEl.classList.add("row-active");
  activeRowEl = trEl;

  // Show drawer + splitter
  drawerEl.classList.add("open");
  document.getElementById("splitter").classList.add("visible");
}

// ── closeDrawer() ─────────────────────────────────────────────
function closeDrawer() {
  drawerEl.classList.remove("open");
  document.getElementById("splitter").classList.remove("visible");
  requests.forEach(r => { r._activeRow = false; });
  if (activeRowEl) { activeRowEl.classList.remove("row-active"); activeRowEl = null; }
  document.querySelectorAll("#req-body tr.row-active").forEach(el => el.classList.remove("row-active"));
  if (typeof closeFindBar === "function") closeFindBar();
}

if (closeBtn) {
  closeBtn.addEventListener("click", closeDrawer);
}

document.addEventListener("keydown", e => {
  if (e.key === "Escape" && drawerEl && drawerEl.classList.contains("open")) {
    closeDrawer(); e.stopPropagation();
  }
});

// ── Splitter (flex sibling, reliable resize) ──────────────────
const splitter = document.getElementById("splitter");
let   isSplitting = false, splitStartX = 0, splitStartW = 0;

if (splitter) {
  splitter.addEventListener("mousedown", e => {
    isSplitting = true;
    splitStartX = e.clientX;
    splitStartW = drawerEl ? drawerEl.offsetWidth : 350;
    splitter.classList.add("dragging");
    document.body.style.cursor     = "col-resize";
    document.body.style.userSelect = "none";
    e.preventDefault();
  });
}

document.addEventListener("mousemove", e => {
  if (!isSplitting) return;
  // Moving left → drawer grows (delta positive)
  const delta    = splitStartX - e.clientX;
  const maxW     = window.innerWidth - 220;   // leave at least 220px for table
  const newWidth = Math.min(Math.max(splitStartW + delta, 260), maxW);
  drawerEl.style.width = newWidth + "px";
});

document.addEventListener("mouseup", () => {
  if (!isSplitting) return;
  isSplitting = false;
  splitter.classList.remove("dragging");
  document.body.style.cursor     = "";
  document.body.style.userSelect = "";
});

// ── Line Diff (LCS Algorithm) ─────────────────────────────────
function computeLineDiff(text1, text2) {
  let str1 = text1 || "";
  let str2 = text2 || "";
  try { str1 = JSON.stringify(JSON.parse(str1), null, 2); } catch {}
  try { str2 = JSON.stringify(JSON.parse(str2), null, 2); } catch {}

  const lines1 = str1 ? str1.split("\n") : [];
  const lines2 = str2 ? str2.split("\n") : [];

  const m = lines1.length;
  const n = lines2.length;
  const dp = Array.from({ length: m + 1 }, () => new Uint16Array(n + 1));

  for (let i = 0; i < m; i++) {
    for (let j = 0; j < n; j++) {
      if (lines1[i] === lines2[j]) {
        dp[i + 1][j + 1] = dp[i][j] + 1;
      } else {
        dp[i + 1][j + 1] = Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
  }

  let i = m, j = n;
  const diff = [];
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && lines1[i - 1] === lines2[j - 1]) {
      diff.unshift({ type: "same", text: lines1[i - 1] });
      i--;
      j--;
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      diff.unshift({ type: "add", text: lines2[j - 1] });
      j--;
    } else if (i > 0 && (j === 0 || dp[i][j - 1] < dp[i - 1][j])) {
      diff.unshift({ type: "del", text: lines1[i - 1] });
      i--;
    }
  }
  return diff;
}

function escapeHTML(str) {
  return (str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function buildSideBySideDiff(diff) {
  const leftRows = [];
  const rightRows = [];
  let leftLineNum = 1;
  let rightLineNum = 1;
  let diffCount = 0;
  let inDiffBlock = false;

  let k = 0;
  while (k < diff.length) {
    const item = diff[k];
    if (item.type === "same") {
      inDiffBlock = false;
      leftRows.push({ num: leftLineNum++, text: item.text, type: "same", blockIndex: -1 });
      rightRows.push({ num: rightLineNum++, text: item.text, type: "same", blockIndex: -1 });
      k++;
    } else {
      const currentBlockIndex = diffCount;
      diffCount++;
      inDiffBlock = true;

      const dels = [];
      const adds = [];
      while (k < diff.length && diff[k].type === "del") {
        dels.push(diff[k++]);
      }
      while (k < diff.length && diff[k].type === "add") {
        adds.push(diff[k++]);
      }
      const maxLen = Math.max(dels.length, adds.length);
      for (let r = 0; r < maxLen; r++) {
        if (r < dels.length) {
          leftRows.push({ num: leftLineNum++, text: dels[r].text, type: "del", blockIndex: currentBlockIndex });
        } else {
          leftRows.push({ num: "", text: "", type: "empty", blockIndex: currentBlockIndex });
        }
        if (r < adds.length) {
          rightRows.push({ num: rightLineNum++, text: adds[r].text, type: "add", blockIndex: currentBlockIndex });
        } else {
          rightRows.push({ num: "", text: "", type: "empty", blockIndex: currentBlockIndex });
        }
      }
    }
  }

  return { leftRows, rightRows, diffCount };
}

// ── SIDE-BY-SIDE DIFF MODAL CONTROLLER ────────────────────────
const diffModalOverlay  = document.getElementById("diff-modal-overlay");
const diffSourceBadge   = document.getElementById("diff-source-badge");
const diffSummaryBadge  = document.getElementById("diff-summary-badge");
const diffNavGroup      = document.getElementById("diff-nav-group");
const diffPrevBtn       = document.getElementById("diff-prev-btn");
const diffNextBtn       = document.getElementById("diff-next-btn");
const diffNavCount      = document.getElementById("diff-nav-count");
const diffModeSplitBtn  = document.getElementById("diff-mode-split");
const diffModeEditBtn   = document.getElementById("diff-mode-edit");
const diffBeautyBtn     = document.getElementById("diff-beauty-btn");
const diffSwapBtn       = document.getElementById("diff-swap-btn");
const diffClearBtn      = document.getElementById("diff-clear-btn");
const diffCloseBtn      = document.getElementById("diff-close-btn");
const diffCopyOrigBtn   = document.getElementById("diff-copy-orig");
const diffCopyTargetBtn = document.getElementById("diff-copy-target");
const diffPasteTargetBtn= document.getElementById("diff-paste-target");
const diffOrigView      = document.getElementById("diff-orig-view");
const diffTargetView    = document.getElementById("diff-target-view");
const diffOrigPre       = document.getElementById("diff-orig-pre");
const diffTargetInput   = document.getElementById("diff-target-input");
const diffTargetPre     = document.getElementById("diff-target-pre");
const diffRunBtn        = document.getElementById("diff-run-btn");

let diffCurrentType     = "response"; // "response" | "request"
let diffOriginalText    = "";
let diffTargetText      = "";
let diffViewMode        = "split";    // "split" | "edit"
let isSyncingScroll     = false;
let currentDiffIndex    = 0;
let totalDiffBlocks     = 0;

function openDiffModal(type = "response") {
  diffCurrentType = type;
  const rawText = copyStore[type] || "";
  diffOriginalText = prettyJSON(rawText);

  if (diffSourceBadge) {
    diffSourceBadge.textContent = type === "response" ? "Response Body" : "Request Body";
  }

  if (diffModalOverlay) {
    diffModalOverlay.style.display = "flex";
  }

  // Set default view mode to Edit Target so user can paste/type immediately
  setDiffViewMode("edit");
  if (diffTargetInput) {
    setTimeout(() => {
      diffTargetInput.focus();
    }, 60);
  }
}

function closeDiffModal() {
  if (diffModalOverlay) {
    diffModalOverlay.style.display = "none";
  }
}

function setDiffViewMode(mode) {
  diffViewMode = mode;
  if (diffModeSplitBtn) diffModeSplitBtn.classList.toggle("active", mode === "split");
  if (diffModeEditBtn)  diffModeEditBtn.classList.toggle("active", mode === "edit");

  if (mode === "edit") {
    if (diffTargetInput) diffTargetInput.style.display = "block";
    if (diffTargetPre)   diffTargetPre.style.display   = "none";
    if (diffTargetInput) diffTargetInput.focus();
  } else {
    if (diffTargetInput) diffTargetInput.style.display = "none";
    if (diffTargetPre)   diffTargetPre.style.display   = "block";
  }
  executeDiff();
}

function executeDiff() {
  if (diffTargetInput && diffViewMode === "edit") {
    diffTargetText = diffTargetInput.value;
  } else if (diffTargetInput) {
    diffTargetText = diffTargetInput.value;
  }

  const origFormatted = prettyJSON(diffOriginalText);
  const targetFormatted = prettyJSON(diffTargetText);

  if (diffViewMode === "edit") {
    // Left side: render raw lines with line numbers
    const lines = origFormatted.split("\n");
    diffOrigPre.innerHTML = lines.map((line, idx) => `
      <div class="diff-row diff-same">
        <span class="diff-line-num">${idx + 1}</span>
        <span class="diff-line-content">${escapeHTML(line)}</span>
      </div>
    `).join("");

    if (diffNavGroup) diffNavGroup.style.display = "none";

    // Update diff summary
    if (!targetFormatted.trim()) {
      if (diffSummaryBadge) diffSummaryBadge.style.display = "none";
    } else {
      const diff = computeLineDiff(origFormatted, targetFormatted);
      const { diffCount } = buildSideBySideDiff(diff);
      renderSummaryBadge(diffCount);
    }
  } else {
    // Split mode: compute and render aligned side-by-side rows
    const diff = computeLineDiff(origFormatted, targetFormatted);
    const { leftRows, rightRows, diffCount } = buildSideBySideDiff(diff);

    diffOrigPre.innerHTML = leftRows.map(r => `
      <div class="diff-row diff-${r.type}" ${r.blockIndex >= 0 ? `data-diff-block="${r.blockIndex}"` : ""}>
        <span class="diff-line-num">${r.num || "&nbsp;"}</span>
        <span class="diff-line-content">${escapeHTML(r.text)}</span>
      </div>
    `).join("");

    diffTargetPre.innerHTML = rightRows.map(r => `
      <div class="diff-row diff-${r.type}" ${r.blockIndex >= 0 ? `data-diff-block="${r.blockIndex}"` : ""}>
        <span class="diff-line-num">${r.num || "&nbsp;"}</span>
        <span class="diff-line-content">${escapeHTML(r.text)}</span>
      </div>
    `).join("");

    renderSummaryBadge(diffCount);
    updateDiffNav(diffCount);
  }
}

function renderSummaryBadge(diffCount) {
  if (!diffSummaryBadge) return;
  diffSummaryBadge.style.display = "inline-block";
  if (diffCount === 0) {
    diffSummaryBadge.className   = "diff-summary-badge identical";
    diffSummaryBadge.textContent = "✓ Identical (No differences)";
  } else {
    diffSummaryBadge.className   = "diff-summary-badge diffs";
    diffSummaryBadge.textContent = `⚠ ${diffCount} difference${diffCount !== 1 ? "s" : ""} found`;
  }
}

// ── STEP-BY-STEP DIFF NAVIGATION ─────────────────────────────
function updateDiffNav(count) {
  totalDiffBlocks = count;
  if (!diffNavGroup || !diffNavCount) return;

  if (count > 0 && diffViewMode === "split") {
    diffNavGroup.style.display = "inline-flex";
    highlightAndScrollDiff(0);
  } else {
    diffNavGroup.style.display = "none";
  }
}

function highlightAndScrollDiff(index) {
  if (totalDiffBlocks === 0) return;
  if (index < 0) index = totalDiffBlocks - 1;
  if (index >= totalDiffBlocks) index = 0;
  currentDiffIndex = index;

  if (diffNavCount) {
    diffNavCount.textContent = `${currentDiffIndex + 1} / ${totalDiffBlocks}`;
  }

  // Smooth scroll first matching diff row into center view (clean red/green without heavy purple borders)
  const targetRows = document.querySelectorAll(`.diff-row[data-diff-block="${currentDiffIndex}"]`);
  const firstRow = targetRows[0];
  if (firstRow) {
    firstRow.scrollIntoView({ block: "center", behavior: "smooth" });
  }
}

function nextDiff() {
  highlightAndScrollDiff(currentDiffIndex + 1);
}

function prevDiff() {
  highlightAndScrollDiff(currentDiffIndex - 1);
}

if (diffPrevBtn) diffPrevBtn.addEventListener("click", prevDiff);
if (diffNextBtn) diffNextBtn.addEventListener("click", nextDiff);

// Keyboard shortcut navigation (F7 / Shift+F7 / Alt+Down / Alt+Up / Enter)
window.addEventListener("keydown", e => {
  if (diffModalOverlay && diffModalOverlay.style.display !== "none") {
    if (e.key === "Escape") {
      closeDiffModal();
    } else if (diffViewMode === "split" && totalDiffBlocks > 0) {
      if (e.key === "F7" || (e.altKey && e.key === "ArrowDown") || (e.key === "Enter" && document.activeElement !== diffTargetInput)) {
        e.preventDefault();
        nextDiff();
      } else if ((e.shiftKey && e.key === "F7") || (e.altKey && e.key === "ArrowUp") || (e.shiftKey && e.key === "Enter" && document.activeElement !== diffTargetInput)) {
        e.preventDefault();
        prevDiff();
      }
    }
  }
});


// Synchronized scrolling between Left and Right panes
if (diffOrigView && diffTargetView) {
  diffOrigView.addEventListener("scroll", () => {
    if (isSyncingScroll) return;
    isSyncingScroll = true;
    diffTargetView.scrollTop  = diffOrigView.scrollTop;
    diffTargetView.scrollLeft = diffOrigView.scrollLeft;
    requestAnimationFrame(() => { isSyncingScroll = false; });
  });

  diffTargetView.addEventListener("scroll", () => {
    if (isSyncingScroll) return;
    isSyncingScroll = true;
    diffOrigView.scrollTop  = diffTargetView.scrollTop;
    diffOrigView.scrollLeft = diffTargetView.scrollLeft;
    requestAnimationFrame(() => { isSyncingScroll = false; });
  });
}

// Real-time diff on typing in textarea
if (diffTargetInput) {
  let diffInputTimer = null;
  diffTargetInput.addEventListener("input", () => {
    clearTimeout(diffInputTimer);
    diffInputTimer = setTimeout(() => {
      diffTargetText = diffTargetInput.value;
      if (diffViewMode === "edit") {
        executeDiff();
      }
    }, 150);
  });
}

// Wire up header buttons
if (diffModeSplitBtn) diffModeSplitBtn.addEventListener("click", () => setDiffViewMode("split"));
if (diffModeEditBtn)  diffModeEditBtn.addEventListener("click",  () => setDiffViewMode("edit"));

if (diffBeautyBtn) {
  diffBeautyBtn.addEventListener("click", () => {
    diffOriginalText = prettyJSON(diffOriginalText);
    if (diffTargetInput) diffTargetInput.value = prettyJSON(diffTargetInput.value);
    diffTargetText = prettyJSON(diffTargetText);
    executeDiff();
    showToast("✨ JSON formatted on both sides");
  });
}

if (diffSwapBtn) {
  diffSwapBtn.addEventListener("click", () => {
    const temp = diffOriginalText;
    diffOriginalText = diffTargetText;
    diffTargetText = temp;
    if (diffTargetInput) diffTargetInput.value = diffTargetText;
    executeDiff();
    showToast("⇄ Left and Right swapped");
  });
}

if (diffClearBtn) {
  diffClearBtn.addEventListener("click", () => {
    if (diffTargetInput) diffTargetInput.value = "";
    diffTargetText = "";
    executeDiff();
  });
}

if (diffCloseBtn) diffCloseBtn.addEventListener("click", closeDiffModal);
if (diffModalOverlay) {
  diffModalOverlay.addEventListener("click", e => {
    if (e.target === diffModalOverlay) closeDiffModal();
  });
}

if (diffCopyOrigBtn) {
  diffCopyOrigBtn.addEventListener("click", () => copyText(diffOriginalText, "Original Content"));
}
if (diffCopyTargetBtn) {
  diffCopyTargetBtn.addEventListener("click", () => copyText(diffTargetText || (diffTargetInput ? diffTargetInput.value : ""), "Target Content"));
}
if (diffPasteTargetBtn) {
  diffPasteTargetBtn.addEventListener("click", async () => {
    let text = "";
    try {
      text = await navigator.clipboard.readText();
    } catch (e) {
      console.warn("navigator.clipboard.readText failed:", e);
    }

    if (text) {
      if (diffTargetInput) diffTargetInput.value = text;
      diffTargetText = text;
      setDiffViewMode("split");
      executeDiff();
      showToast("📋 Pasted into Comparison Target");
    } else {
      setDiffViewMode("edit");
      if (diffTargetInput) {
        diffTargetInput.focus();
        diffTargetInput.select();
        showToast("Press Ctrl+V to paste into the right box");
      }
    }
  });
}


if (diffRunBtn) {
  diffRunBtn.addEventListener("click", () => {
    setDiffViewMode("split");
  });
}

// Wire up toolbar Compare buttons
const compareToggleReqBtn  = document.getElementById("compare-toggle-request");
const compareToggleRespBtn = document.getElementById("compare-toggle-response");

if (compareToggleReqBtn) {
  compareToggleReqBtn.addEventListener("click", () => openDiffModal("request"));
}
if (compareToggleRespBtn) {
  compareToggleRespBtn.addEventListener("click", () => openDiffModal("response"));
}


// ═══════════════════════════════════════════════════════════════
//  REPLAY / RESEND REQUEST (Mini-Postman)
// ═══════════════════════════════════════════════════════════════

if (replayBeautyBtn) {
  replayBeautyBtn.addEventListener("click", () => {
    replayBodyInput.value = prettyJSON(replayBodyInput.value);
  });
}

if (replayCopyBtn) {
  replayCopyBtn.addEventListener("click", () => {
    copyText(prettyJSON(replayLastResponseText), "Replay Response");
  });
}

async function executeReplayRequest(url, method, headersObj, bodyVal) {
  // 1. Send via background service worker (Runs with <all_urls> + declarativeNetRequest CORS Bypass Rule)
  if (typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.sendMessage === "function") {
    try {
      const bgResult = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          {
            type: "REPLAY_REQUEST",
            url,
            method,
            headers: headersObj,
            body: bodyVal,
          },
          response => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else if (!response) {
              reject(new Error("No response from background service worker"));
            } else if (!response.ok) {
              reject(new Error(response.error || "Request failed"));
            } else {
              resolve(response);
            }
          }
        );
      });
      return bgResult;
    } catch (bgErr) {
      // Silently proceed to tab context fallback
    }
  }

  // 2. Fallback: Try sending directly inside the inspected tab context
  if (typeof chrome !== "undefined" && chrome.devtools && chrome.devtools.inspectedWindow) {
    try {
      const pageResult = await new Promise((resolve, reject) => {
        const payloadCode = `
          (async () => {
            const start = performance.now();
            try {
              const fetchHeaders = new Headers();
              const hObj = ${JSON.stringify(headersObj)};
              for (const [k, v] of Object.entries(hObj)) {
                try { fetchHeaders.append(k, v); } catch(e) {}
              }
              const opts = {
                method: ${JSON.stringify(method || "GET")},
                headers: fetchHeaders,
                credentials: "include"
              };
              if (!["GET", "HEAD"].includes(opts.method) && ${JSON.stringify(bodyVal || "")}) {
                opts.body = ${JSON.stringify(bodyVal || "")};
              }
              const res = await fetch(${JSON.stringify(url)}, opts);
              const dur = Math.round(performance.now() - start);
              const txt = await res.text();
              return { ok: true, status: res.status, statusText: res.statusText || "", duration: dur, body: txt };
            } catch (err) {
              return { ok: false, error: err.message || String(err), duration: Math.round(performance.now() - start) };
            }
          })()
        `;

        chrome.devtools.inspectedWindow.eval(payloadCode, (result, isException) => {
          if (isException) {
            reject(new Error(isException.value || "Tab eval exception"));
          } else if (!result) {
            reject(new Error("No response from inspected tab"));
          } else if (!result.ok) {
            reject(new Error(result.error || "Tab fetch error"));
          } else {
            resolve(result);
          }
        });
      });
      return pageResult;
    } catch (pageErr) {
      // Silently proceed to direct fetch fallback
    }
  }

  // 3. Direct fallback runner using fetch
  const startTime = performance.now();
  const fetchHeaders = new Headers();
  Object.entries(headersObj).forEach(([k, v]) => {
    try { fetchHeaders.append(k, v); } catch {}
  });

  const options = {
    method: method || "GET",
    headers: fetchHeaders,
  };

  if (!["GET", "HEAD"].includes(options.method) && bodyVal) {
    options.body = bodyVal;
  }

  const res = await fetch(url, options);
  const duration = Math.round(performance.now() - startTime);
  const text = await res.text();

  return {
    ok: true,
    status: res.status,
    statusText: res.statusText || "",
    duration: duration,
    body: text,
  };
}



if (replaySendBtn) {
  replaySendBtn.addEventListener("click", async () => {
    const url = (replayUrlInput ? replayUrlInput.value : "").trim();
    if (!url) {
      showToast("⚠ Please enter a URL");
      return;
    }

    const method = replayMethodInput ? replayMethodInput.value : "GET";
    replaySendBtn.textContent = "⏳ Sending...";
    replaySendBtn.disabled = true;

    // Parse headers and filter out unsafe browser headers
    const headersObj = {};
    const lines = (replayHeadersInput ? replayHeadersInput.value : "").split("\n");
    lines.forEach(line => {
      const idx = line.indexOf(":");
      if (idx > 0) {
        const k = line.slice(0, idx).trim();
        const v = line.slice(idx + 1).trim();
        if (k && v && isSafeHeader(k)) {
          headersObj[k] = v;
        }
      }
    });

    const bodyVal = (!["GET", "HEAD"].includes(method) && replayBodyInput && replayBodyInput.value) ? replayBodyInput.value : null;

    try {
      const result = await executeReplayRequest(url, method, headersObj, bodyVal);

      replayLastResponseText = result.body || "";
      if (replayResStatus) {
        replayResStatus.textContent = `${result.status} ${result.statusText}`;
        replayResStatus.className = `replay-status-badge ${statusClass(result.status)}`;
      }
      if (replayResTime) {
        replayResTime.textContent = `${result.duration} ms`;
      }
      if (replayResBody) {
        renderPre(replayResBody, result.body);
      }
      if (replayResContainer) {
        replayResContainer.style.display = "block";
      }
      showToast(`✓ Response: ${result.status} (${result.duration}ms)`);
    } catch (err) {
      if (replayResStatus) {
        replayResStatus.textContent = "Error";
        replayResStatus.className = "replay-status-badge s5xx";
      }
      if (replayResTime) {
        replayResTime.textContent = "—";
      }
      if (replayResBody) {
        replayResBody.textContent = `Request failed: ${err.message}`;
      }
      if (replayResContainer) {
        replayResContainer.style.display = "block";
      }
      showToast(`⚠ Error: ${err.message}`);
    } finally {
      replaySendBtn.textContent = "🚀 Send";
      replaySendBtn.disabled = false;
    }
  });
}

// ═══════════════════════════════════════════════════════════════
//  IN-TAB SEARCH / FIND BAR (Ctrl+F)
// ═══════════════════════════════════════════════════════════════

const findBar      = document.getElementById("drawer-find-bar");
const findInput    = document.getElementById("find-input");
const findCount    = document.getElementById("find-count");
const findPrevBtn  = document.getElementById("find-prev-btn");
const findNextBtn  = document.getElementById("find-next-btn");
const findCloseBtn = document.getElementById("find-close-btn");

let findMatches      = [];
let findCurrentIndex = -1;

function getActivePanelContainer() {
  const activePanel = document.querySelector(".dw-panel.active");
  return activePanel || null;
}

function clearHighlights(container) {
  if (!container) return;
  const marks = container.querySelectorAll("mark.find-match");
  marks.forEach(mark => {
    const parent = mark.parentNode;
    if (parent) {
      parent.replaceChild(document.createTextNode(mark.textContent), mark);
      parent.normalize();
    }
  });
}

function highlightInContainer(container, query) {
  clearHighlights(container);
  findMatches = [];
  findCurrentIndex = -1;

  if (!query || !container) {
    updateFindCount();
    return;
  }

  const qLower = query.toLowerCase();
  const walker = document.createTreeWalker(
    container,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        if (node.parentElement && node.parentElement.closest(".compare-box")) {
          return NodeFilter.FILTER_REJECT;
        }
        if (node.nodeValue && node.nodeValue.toLowerCase().includes(qLower)) {
          return NodeFilter.FILTER_ACCEPT;
        }
        return NodeFilter.FILTER_SKIP;
      }
    }
  );

  const textNodes = [];
  while (walker.nextNode()) {
    textNodes.push(walker.currentNode);
  }

  textNodes.forEach(node => {
    const text = node.nodeValue;
    const lower = text.toLowerCase();
    const frag = document.createDocumentFragment();
    let lastIdx = 0;
    let idx = lower.indexOf(qLower, lastIdx);

    while (idx !== -1) {
      if (idx > lastIdx) {
        frag.appendChild(document.createTextNode(text.substring(lastIdx, idx)));
      }
      const mark = document.createElement("mark");
      mark.className = "find-match";
      mark.textContent = text.substring(idx, idx + query.length);
      frag.appendChild(mark);
      findMatches.push(mark);
      lastIdx = idx + query.length;
      idx = lower.indexOf(qLower, lastIdx);
    }
    if (lastIdx < text.length) {
      frag.appendChild(document.createTextNode(text.substring(lastIdx)));
    }
    if (node.parentNode) {
      node.parentNode.replaceChild(frag, node);
    }
  });

  if (findMatches.length > 0) {
    findCurrentIndex = 0;
    selectMatch(0);
  } else {
    updateFindCount();
  }
}

function selectMatch(index) {
  if (!findMatches.length) {
    findCurrentIndex = -1;
    updateFindCount();
    return;
  }
  findMatches.forEach(m => m.classList.remove("active"));
  findCurrentIndex = (index + findMatches.length) % findMatches.length;
  const current = findMatches[findCurrentIndex];
  if (current) {
    current.classList.add("active");
    current.scrollIntoView({ block: "center", behavior: "smooth" });
  }
  updateFindCount();
}

function updateFindCount() {
  if (findMatches.length === 0) {
    findCount.textContent = findInput.value ? "0/0" : "";
  } else {
    findCount.textContent = `${findCurrentIndex + 1}/${findMatches.length}`;
  }
}

function performFind() {
  const query = findInput.value.trim();
  const container = getActivePanelContainer();
  highlightInContainer(container, query);
}

function openFindBar() {
  findBar.style.display = "flex";
  document.querySelectorAll(".panel-find-btn").forEach(b => b.classList.add("active"));
  findInput.focus();
  findInput.select();
  performFind();
}

function closeFindBar() {
  findBar.style.display = "none";
  document.querySelectorAll(".panel-find-btn").forEach(b => b.classList.remove("active"));
  findMatches = [];
  findCurrentIndex = -1;
  document.querySelectorAll(".dw-panel").forEach(clearHighlights);
}

// 🔍 Find toggle buttons in toolbars
["headers", "request", "response"].forEach(tabName => {
  const btn = document.getElementById(`find-toggle-${tabName}`);
  if (btn) {
    btn.addEventListener("click", () => {
      if (findBar.style.display !== "none") {
        closeFindBar();
      } else {
        openFindBar();
      }
    });
  }
});

if (findInput) {
  findInput.addEventListener("input", performFind);

  findInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault();
      if (e.shiftKey) {
        selectMatch(findCurrentIndex - 1);
      } else {
        selectMatch(findCurrentIndex + 1);
      }
    } else if (e.key === "Escape") {
      closeFindBar();
    }
  });
}

if (findNextBtn) {
  findNextBtn.addEventListener("click", () => selectMatch(findCurrentIndex + 1));
}
if (findPrevBtn) {
  findPrevBtn.addEventListener("click", () => selectMatch(findCurrentIndex - 1));
}
if (findCloseBtn) {
  findCloseBtn.addEventListener("click", closeFindBar);
}

// Global Ctrl+F / Cmd+F handler (Capture phase: prevents default browser find bar)
window.addEventListener("keydown", e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    if (drawerEl && drawerEl.classList.contains("open")) {
      if (findBar.style.display !== "none" && document.activeElement === findInput) {
        findInput.select();
      } else {
        openFindBar();
      }
    } else {
      searchBox.focus();
      searchBox.select();
    }
  }
}, true);

// Re-run search if user switches tabs while find bar is open
dwTabs.forEach(tab => {
  tab.addEventListener("click", () => {
    if (findBar.style.display !== "none") {
      setTimeout(performFind, 20);
    }
  });
});

// ── Init: load any mocks saved in storage ─────────────────────
loadMocksFromBackground();





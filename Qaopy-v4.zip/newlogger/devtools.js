﻿// devtools.js – registers the qaopy panel in Chrome DevTools
chrome.devtools.panels.create(
  "qaopy",          // panel title shown in DevTools tab bar
  null,             // icon (null = default)
  "panel.html",     // the HTML page that renders inside the panel
  function (panel) {
    console.log("[qaopy] Panel created:", panel);
  }
);
